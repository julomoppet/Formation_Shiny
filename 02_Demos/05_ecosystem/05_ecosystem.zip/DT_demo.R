library(shiny)
library(DT)

ui <- fluidPage(h1('Tableau'),
        fluidRow(column(6, DT::dataTableOutput('x1')),
        column(6, plotOutput('x2', height = 500))))

server <- shinyServer(function(input, output, session) {
    output$x1 = DT::renderDataTable(cars, server = FALSE)
    output$x2 = renderPlot({s = input$x1_rows_selected
        
    par(mar = c(4, 4, 1, .1))
    plot(cars)
        if (length(s)) points(cars[s, , drop = FALSE], 
                              pch = 19, cex = 2)})})

shinyApp(ui, server)